ENVIRONMENTAL MODELLING & SOFTWARE SLR — SUPPLEMENTARY EVIDENCE PACKAGE
Version: 1.3
Prepared: 15 November 2026

Review: Reinforcement Learning for Optimal Sensor Placement in Water Distribution Networks: A Systematic Literature Review.

PACKAGE SCOPE
This package contains supporting methods, search strategies, Covidence provenance, screening and extraction records, included-study register, descriptive appraisal, PRISMA figure, highlights, and editable graphical-abstract source. It is an evidence and reproducibility supplement, not the journal-submission manuscript.

EXCLUDED
- EMS journal-submission manuscript and all working manuscript drafts.
- Publisher-formatted full-text PDFs and full article texts.

PRISMA FLOW
417 records imported; 40 duplicates removed; 377 title/abstract records screened; 336 excluded at title/abstract; 41 full texts assessed; 37 full-text exclusions; 4 studies included.

PROVENANCE LIMITATIONS
1. The full-text exclusion register contains all 37 excluded full-text records and their recorded reasons.
2. The complete title/abstract screening export for all 377 records was not recovered. The partial register supplied must not be represented as a complete screening log.
3. Screening and extraction were conducted by one reviewer.
4. The extraction export contains four individual reviewer records and one additional consensus record. The updated workbook includes the workflow-status verification note.
5. Individual Covidence study pages show completed extraction for all four included studies, while the aggregate dashboard displayed 3 In progress and 1 Complete. The cause remains unknown.
6. Ettyem et al. (#286): the original network/benchmark-name field is blank, while the dataset-source field identifies Thi-Qar urban WDN, Iraq; this is documented as a cross-field reconciliation.
7. Sukya et al. Bayesian-optimisation study (#7): the conflict-of-interest field was blank. Grant acknowledgement is not treated as a COI declaration.
8. Covidence import dates are not asserted to be exact database query execution dates.
9. The adapted ten-criterion appraisal is descriptive and is not a validated standardised instrument.
10. The protocol was configured in Covidence using PICOS but was not separately registered in an external public prospective registry.

FOLDER CONTENTS
01 protocol and methods; 02 database search strategies; 03 screening and PRISMA; 04 included studies; 05 manuscript-derived synthesis; 06 methodological appraisal; 07 figures and supplementary materials; 08 recovered Covidence exports; 10 pending author exports.

RIGHTS
No licence is asserted. Confirm author ownership and permissions before selecting a licence. Publisher PDFs and full article texts are excluded.
