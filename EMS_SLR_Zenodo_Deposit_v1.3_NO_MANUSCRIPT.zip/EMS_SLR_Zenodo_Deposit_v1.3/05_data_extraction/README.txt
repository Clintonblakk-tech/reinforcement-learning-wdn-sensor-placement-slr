MANUSCRIPT-DERIVED SYNTHESIS

This folder contains the manuscript-derived four-study synthesis and the extraction workflow status verification note. The canonical Covidence export workbook and its individual/consensus CSV records are retained once, in 08_covidence_exports/. This avoids duplicate, potentially divergent copies.

The extraction export includes four individual reviewer records and one additional consensus record. See 08_covidence_exports/Extraction_Export_Provenance.txt and Covidence_Extraction_Workflow_Status_Verification.txt for provenance and the aggregate dashboard discrepancy.
