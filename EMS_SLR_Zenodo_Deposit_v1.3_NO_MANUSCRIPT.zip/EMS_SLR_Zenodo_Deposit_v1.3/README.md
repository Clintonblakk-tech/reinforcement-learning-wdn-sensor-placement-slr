# SLR Supporting Evidence and Reproducibility Materials — Version 1.3

Review: **Reinforcement Learning for Optimal Sensor Placement in Water Distribution Networks: A Systematic Literature Review.**

This archival supplement contains supporting methods, search strategies, Covidence screening provenance, PRISMA counts, included-study records, extraction records, descriptive appraisal, and supplementary figures. It excludes the journal-submission manuscript, working manuscript drafts, publisher-formatted PDFs, and full article texts.

## PRISMA flow
- Records imported: 417
- Duplicates removed: 40
- Title/abstract records screened: 377
- Title/abstract exclusions: 336
- Full-text reports assessed: 41
- Full-text exclusions: 37 (27 wrong intervention; 6 wrong study type; 4 wrong population)
- Included studies: 4

## Important methodological and provenance limitations
- One reviewer conducted screening and extraction.
- The complete decision-level export for all 377 title/abstract records was not recovered. A partial register and the recovered 37-record full-text exclusion register are supplied; the partial register is not a complete screening log.
- Covidence import dates are not necessarily the exact dates on which each database query was executed.
- The extraction export contains four individual reviewer records and one additional consensus record. The workbook preserves the original export and workflow verification.
- Individual Covidence study pages showed completed extraction for all four included studies, while the aggregate dashboard showed 3 In progress and 1 Complete. The reason for this discrepancy is unknown.
- Ettyem et al. (Covidence #286): the original “Network or benchmark name” field is blank, while another field identifies the Thi-Qar urban WDN, Iraq. This is retained as a cross-field reconciliation, not a silent alteration of the original field.
- Sukya et al. (Bayesian-optimisation study; Covidence #7): the conflict-of-interest extraction field is blank. The article acknowledgement of ITS 2026 Batch 1 Research Grant funding is not treated as a conflict-of-interest declaration.
- The adapted ten-criterion appraisal is descriptive, not a validated standardised instrument; no overall score was calculated.
- The protocol and eligibility criteria were configured in Covidence using PICOS; the protocol was not separately registered in an external public prospective review registry.

## Folder guide
- \`01_protocol_and_methods/\`: methods summary.
- \`02_search_strategies/\`: database-specific strategies and search provenance.
- \`03_screening_and_PRISMA/\`: import history, PRISMA counts, provenance notes and import-history evidence.
- \`04_included_studies/\`: four-study register and primary-study evidence verification report.
- \`05_data_extraction/\`: manuscript-derived synthesis and extraction workflow note.
- \`06_methodological_appraisal/\`: appraisal matrix and rating guide.
- \`07_figures_and_supplementary/\`: PRISMA figure, highlights and editable graphical-abstract source.
- \`08_covidence_exports/\`: recovered screening and extraction registers, individual/consensus records, field completeness and reconciliation.
- \`10_pending_author_exports/\`: outstanding export limitations.

## Rights and licensing
No licence is asserted. Authors must confirm ownership and reuse permissions before selecting a licence. Publisher PDFs and full article texts are excluded. See \`PUBLIC_CONTENT_AND_RIGHTS_NOTE.txt\`.

## Citation and DOI
This is version 1.3 of the supporting evidence package. No DOI has been assigned at preparation time. A DOI should be cited only after the Zenodo record has been published.
